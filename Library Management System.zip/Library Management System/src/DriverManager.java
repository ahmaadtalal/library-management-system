import java.sql.SQLException;

class DriverManager {

    static java.sql.Connection getConnection(String url, String mysqluser, String mysqlpwd) throws SQLException {
        return java.sql.DriverManager.getConnection(url, mysqluser, mysqlpwd);
    }
}
