import java.time.LocalDate;

public class BorrowingHistory {
    private int serialNumber;
    private String bookId;
    private String bookName;
    private int copies;
    private String status;
    private LocalDate date;

    public BorrowingHistory(int serialNumber, String bookId, String bookName, int copies, String status, LocalDate date) {
        this.serialNumber = serialNumber;
        this.bookId = bookId;
        this.bookName = bookName;
        this.copies = copies;
        this.status = status;
        this.date = date;
    }

    public int getSerialNumber() {
        return serialNumber;
    }

    public String getBookId() {
        return bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public int getCopies() {
        return copies;
    }

    public String getStatus() {
        return status;
    }

    public LocalDate getDate() {
        return date;
    }
}